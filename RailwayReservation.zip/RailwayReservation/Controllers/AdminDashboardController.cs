using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RailwayReservation.Models;

namespace RailwayReservation.Controllers
{
    public class AdminDashboardController : Controller
    {
        private readonly ILogger<AdminDashboardController> _logger;
        private readonly RailwayReservationContext _context;

        public AdminDashboardController(ILogger<AdminDashboardController> logger, RailwayReservationContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            var today = DateOnly.FromDateTime(DateTime.Today);

            var model = new AdminDashboardViewModel
            {
                TotalTrains = _context.Trains.Count(),
                TotalUsers = _context.Users.Count(),
                TotalPassengers = _context.Passengers.Count(),
                TotalReservations = _context.Reservations.Count(),
                TodaysReservations = _context.Reservations
                    .Where(r => r.RBookingDate == today) // Adjust ReservationDate to your actual date field
                    .ToList()
            };

            return View(model);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}
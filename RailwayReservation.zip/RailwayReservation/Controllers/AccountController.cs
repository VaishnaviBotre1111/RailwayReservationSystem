using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using RailwayReservation.Models;

namespace RailwayReservation.Controllers
{
    // [Route("[controller]")]
    public class AccountController : Controller
    {
        private readonly RailwayReservationContext _context;

        public AccountController(RailwayReservationContext context)
        {
            _context = context;
        }

        // GET: Account/Register  -- render registration form
        public IActionResult Register()
        {
            return View();
        }


        // POST: Account/Register
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegistrationViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Check if the email already exists
                var existingUser = await _context.Users
                    .FirstOrDefaultAsync(u => u.UEmail == model.Email);
                if (existingUser != null)
                {
                    ModelState.AddModelError("Email", "Email already in use.");
                    return View(model);
                }

                // Create a new user object
                var user = new User
                {
                    UName = model.Name,
                    UEmail = model.Email,
                    UPassword = model.Password, // Consider hashing the password
                    UAddress = model.Address
                };

                // Add the user to the database
                _context.Users.Add(user);
                await _context.SaveChangesAsync();

                // Optionally log the user in or redirect to the login page
                return RedirectToAction("Login");
            }

            return View(model);
        }

        // GET: Account/Login
        public IActionResult Login()
        {
            return View();
        }

        // POST: Account/Login
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                var admin = await _context.Admins
                    .FirstOrDefaultAsync(a => a.AEmail == model.Email && a.APassword == model.Password);

                if (admin != null)
                {
                    // Accessing HttpContext.Session correctly
                    HttpContext.Session.SetString("UserType", "Admin");
                    HttpContext.Session.SetString("AdminName", admin.AName);
                    HttpContext.Session.SetString("AdminEmail", admin.AEmail);
                    return RedirectToAction("Index", "AdminDashboard");
                }

                var user = await _context.Users
                    .FirstOrDefaultAsync(u => u.UEmail == model.Email && u.UPassword == model.Password);

                if (user != null)
                {
                    HttpContext.Session.SetString("UserType", "User");
                    HttpContext.Session.SetInt32("UserId", user.UId);
                    HttpContext.Session.SetString("UserName", user.UName);
                    HttpContext.Session.SetString("UserEmail", user.UEmail);
                    return RedirectToAction("Index", "UserDashboard");
                }

                ModelState.AddModelError(string.Empty, "Invalid login attempt.");
            }

            return View(model);
        }
        // GET: Account/Logout
        public IActionResult Logout()
        {
            // Clear session
            HttpContext.Session.Clear();
            Response.Headers.Append("Location", Url.Action("Login"));
            return StatusCode(302);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}
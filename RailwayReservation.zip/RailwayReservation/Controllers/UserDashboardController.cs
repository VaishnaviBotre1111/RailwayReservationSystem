using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using RailwayReservation.Models;

namespace RailwayReservation.Controllers
{
    public class UserDashboardController : Controller
    {
        private readonly ILogger<UserDashboardController> _logger;
        private readonly RailwayReservationContext _context;

        public UserDashboardController(ILogger<UserDashboardController> logger, RailwayReservationContext context)
        {
            _logger = logger;
            _context = context;
        }

        // GET: UserDashboard
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        // GET: UserDashboard/Trains
        [HttpGet("Trains")]
        public async Task<IActionResult> Trains()
        {
            var trains = await _context.Trains.ToListAsync();
            var model = new TrainSearchViewModel { Trains = trains };
            return View(model);
        }

        // POST: UserDashboard/Trains
        [HttpPost("Trains")]
        public IActionResult Trains(TrainSearchViewModel model)
        {
            // Start with the full list of trains
            var trains = _context.Trains.AsQueryable();

            // Apply filters based on user input
            if (!string.IsNullOrEmpty(model.TName))
            {
                trains = trains.Where(t => t.TName.ToLower().Contains(model.TName.ToLower()));
            }
            if (!string.IsNullOrEmpty(model.TSource))
            {
                trains = trains.Where(t => t.TSource.ToLower().Contains(model.TSource.ToLower()));
            }
            if (!string.IsNullOrEmpty(model.TDestination))
            {
                trains = trains.Where(t => t.TDestination.ToLower().Contains(model.TDestination.ToLower()));
            }
            if (model.TDepartureDate.HasValue)
            {
                trains = trains.Where(t => t.TDepartureDate == model.TDepartureDate.Value);
            }

            model.Trains = trains.ToList(); // Populate model with filtered trains
            return View(model);
        }

        // GET: UserDashboard/TrainDetails
        [HttpGet("TrainDetails/{id}")]
        public async Task<IActionResult> TrainDetails(int id)
        {
            var train = await _context.Trains.FindAsync(id);
            if (train == null)
            {
                return NotFound(); // Handle case where train is not found
            }

            // Store train details in session
            HttpContext.Session.SetInt32("TrainId", train.TId);
            HttpContext.Session.SetString("TrainPrice", train.TFare.ToString("F2"));

            var bookingRules = "1. Tickets must be booked at least 24 hours in advance.\n" +
                               "2. Each passenger must have a valid ID.\n" +
                               "3. Children under 5 travel for free.";

            var cancellationRules = "1. Cancellations must be made at least 12 hours before departure.\n" +
                                    "2. A cancellation fee of 20% will be applied.\n" +
                                    "3. Refunds will be processed within 5-7 business days.";

            var viewModel = new TrainDetailsViewModel
            {
                Train = train,
                BookingRules = bookingRules,
                CancellationRules = cancellationRules
            };

            return View(viewModel);
        }

        // POST: UserDashboard/BookTicket
        [HttpPost("BookTicket")]
        public IActionResult BookTicket()
        {
            var model = new PassengerViewModel(); // Initialize an empty model
            return View("BookTicket", model);
        }

        // POST: UserDashboard/ConfirmBooking
        [HttpPost("ConfirmBooking")]
        public IActionResult ConfirmBooking(PassengerViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View("BookTicket", model); // Return view with validation errors
            }

            // Retrieve UserId and TrainId from session
            int? userId = HttpContext.Session.GetInt32("UserId");
            int? trainId = HttpContext.Session.GetInt32("TrainId");

            if (userId == null || trainId == null)
            {
                return RedirectToAction("Error", "Home", new { message = "Session values are missing. Please try again." });
            }

            // Determine next available seat number
            int nextSeatNumber = _context.Passengers.Any()
                ? _context.Passengers.Max(p => p.PSeatNo) + 1
                : 1;

            // Create and save the passenger record
            var passenger = new Passenger
            {
                PName = model.Name,
                PEmail = model.Email,
                PAge = model.Age,
                PGender = model.Gender,
                PAdharNo = model.AdharNo,
                PDob = model.Dob,
                PMobileNo = model.MobileNo,
                PAddress = model.Address,
                PSeatNo = nextSeatNumber
            };

            _context.Passengers.Add(passenger);
            _context.SaveChanges();

            // Retrieve the train ticket price safely
            string trainPriceString = HttpContext.Session.GetString("TrainPrice");
            if (!decimal.TryParse(trainPriceString, out decimal trainTicketPrice))
            {
                return RedirectToAction("Error", "Home", new { message = "Invalid train price." });
            }

            // Calculate the total price
            decimal totalPrice = CalculateTicketPrice(passenger.PAge, trainTicketPrice);

            // Create and save the reservation record
            var reservation = new Reservation
            {
                UId = userId.Value,
                TId = trainId.Value,
                RTotalPrice = totalPrice,
                RBookingDate = DateOnly.FromDateTime(DateTime.Now),
                RPaymentStatus = "Pending",
                RBookingStatus = "Pending",
                PnrNo = passenger.PnrNo // Assuming PnrNo is managed correctly
            };

            _context.Reservations.Add(reservation);
            _context.SaveChanges();

            return RedirectToAction("Confirmation");
        }

        // GET: UserDashboard/Confirmation
        [HttpGet("Confirmation")]
        public IActionResult Confirmation()
        {
            return View();
        }

        // Calculate ticket price based on age
        private decimal CalculateTicketPrice(int age, decimal trainTicketPrice)
        {
            if (age < 0) return 0; // Handle invalid age
            if (age <= 5) return 0; // Free for children under 5
            if (age <= 12) return trainTicketPrice * 0.20m; // 20% for children
            if (age >= 65) return trainTicketPrice * 0.70m; // 70% for seniors
            return trainTicketPrice; // Full price for adults
        }

        // GET: UserDashboard/MyReservations
        [HttpGet("MyReservations")]
        public async Task<IActionResult> MyReservations()
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var reservations = await _context.Reservations
                .Where(r => r.UId == userId.Value)
                .Include(r => r.TIdNavigation)
                .Include(r => r.UIdNavigation)
                .Include(r => r.PnrNoNavigation)
                .Select(r => new ReservationDetailsViewModel
                {
                    ReservationId = r.RId,
                    TrainId = r.TId,
                    UserId = r.UId,
                    PnrNo = r.PnrNo,
                    TotalPrice = r.RTotalPrice,
                    TrainName = r.TIdNavigation.TName,
                    UserName = r.UIdNavigation.UName,
                    Source = r.TIdNavigation.TSource,
                    Destination = r.TIdNavigation.TDestination,
                    DepartureDate = r.TIdNavigation.TDepartureDate,
                    PaymentStatus = r.RPaymentStatus,
                    BookingStatus = r.RBookingStatus,
                    PassengerName = r.PnrNoNavigation.PName,
                    PassengerAge = r.PnrNoNavigation.PAge,
                    PassengerAddress = r.PnrNoNavigation.PAddress,
                    PassengerMobileNo = r.PnrNoNavigation.PMobileNo,
                    PassengerAdharNo = r.PnrNoNavigation.PAdharNo,
                    SeatNo = r.PnrNoNavigation.PSeatNo
                })
                .ToListAsync();

            return View(reservations);
        }

        // GET: UserDashboard/ReservationDetails
        [HttpGet("ReservationDetails/{id}")]
        public async Task<IActionResult> ReservationDetails(int id)
        {
            var reservation = await _context.Reservations
                .Include(r => r.TIdNavigation)
                .Include(r => r.UIdNavigation)
                .Include(r => r.PnrNoNavigation)
                .FirstOrDefaultAsync(r => r.RId == id);

            if (reservation == null)
            {
                return NotFound();
            }

            return View(reservation);
        }

        // GET: UserDashboard/ConfirmDelete
        [HttpGet("ConfirmDelete/{id}")]
        public async Task<IActionResult> ConfirmDelete(int id)
        {
            var reservation = await _context.Reservations
                .Include(r => r.TIdNavigation)
                .Include(r => r.UIdNavigation)
                .Include(r => r.PnrNoNavigation)
                .FirstOrDefaultAsync(r => r.RId == id);

            if (reservation == null)
            {
                return NotFound();
            }

            return View(reservation);
        }

        // POST: UserDashboard/DeleteReservation
        [HttpPost("DeleteReservation/{id}")]
        public async Task<IActionResult> DeleteReservation(int id)
        {
            var reservation = await _context.Reservations.FindAsync(id);
            if (reservation == null)
            {
                return NotFound();
            }

            _context.Reservations.Remove(reservation);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(MyReservations));
        }

        // GET: UserDashboard/ConfirmCancellation
        [HttpGet("ConfirmCancellation/{id}")]
        public async Task<IActionResult> ConfirmCancellation(int id)
        {
            var reservation = await _context.Reservations
                .Include(r => r.TIdNavigation)
                .Include(r => r.UIdNavigation)
                .Include(r => r.PnrNoNavigation)
                .FirstOrDefaultAsync(r => r.RId == id);

            if (reservation == null)
            {
                return NotFound();
            }

            return View(reservation);
        }

        // POST: UserDashboard/CancelReservation
        [HttpPost("CancelReservation/{id}")]
        public async Task<IActionResult> CancelReservation(int id)
        {
            var reservation = await _context.Reservations.FindAsync(id);
            if (reservation == null)
            {
                return NotFound();
            }

            reservation.RBookingStatus = "Cancelled";
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(MyReservations));
        }

        // POST: UserDashboard/PayNow
        [HttpPost("PayNow/{id}")]
        public async Task<IActionResult> PayNow(int id)
        {
            var reservation = await _context.Reservations.FindAsync(id);
            if (reservation == null)
            {
                return NotFound();
            }

            reservation.RPaymentStatus = "Success";
            reservation.RBookingStatus = "Booked";
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(MyReservations));
        }

        // GET: UserDashboard/Profile
        [HttpGet("Profile")]
        public async Task<IActionResult> Profile()
        {
            var userEmail = HttpContext.Session.GetString("UserEmail");
            if (userEmail == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var user = await _context.Users.FirstOrDefaultAsync(u => u.UEmail == userEmail);
            if (user == null)
            {
                return NotFound(); // Handle user not found
            }

            return View(user);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error(string message)
        {
            ViewData["ErrorMessage"] = message; // Pass error message to the view
            return View("Error");
        }
    }
}

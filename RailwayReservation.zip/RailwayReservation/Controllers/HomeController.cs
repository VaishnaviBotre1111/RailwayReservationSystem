using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RailwayReservation.Models;

namespace RailwayReservation.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    private readonly RailwayReservationContext _context;
    public HomeController(ILogger<HomeController> logger, RailwayReservationContext context)
    {
        _logger = logger;
        _context = context;
    }

    public IActionResult Index()
    {
        return View();
    }

    // Trains action
        public async Task<IActionResult> Trains()
        {
            var trains = await _context.Trains.ToListAsync(); // Fetch trains from the database
            return View(trains);
        }

        // GET: Home/About
        public IActionResult About()
        {
            return View("About_us");
        }

        // GET: Home/Contact
        public IActionResult Contact()
        {
            return View("Contact_us");
        }

        // POST: Home/Contact
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Contact(ContactViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Here, you could send an email or save the message to the database
                // For simplicity, we'll just redirect back to the Contact page with a success message.
                TempData["SuccessMessage"] = "Thank you for your message! We will get back to you soon.";
                return RedirectToAction("Contact");
            }

            return View("Contact_us", model);
        }


    
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}

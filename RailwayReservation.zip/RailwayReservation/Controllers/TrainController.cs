using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RailwayReservation.Models;

namespace RailwayReservation.Controllers
{
    public class TrainController : Controller
    {
        private readonly RailwayReservationContext _context;

        public TrainController(RailwayReservationContext context)
        {
            _context = context;
        }

        // GET: Train
        public async Task<IActionResult> Index()
        {
            var railwayReservationContext = _context.Trains.Include(t => t.AIdNavigation);
            return View(await railwayReservationContext.ToListAsync());
        }

        // GET: Train/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var train = await _context.Trains
                .Include(t => t.AIdNavigation)
                .FirstOrDefaultAsync(m => m.TId == id);
            if (train == null)
            {
                return NotFound();
            }

            return View(train);
        }

        // GET: Train/Create
        public IActionResult Create()
        {
            ViewData["AId"] = new SelectList(_context.Admins, "AId", "AId");
            return View();
        }

        // POST: Train/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("TId,AId,TName,TSource,TDestination,TDepartureDate,TArrivalTime,TDepartureTime,TFare")] Train train)
        {
            if (ModelState.IsValid)
            {
                _context.Add(train);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["AId"] = new SelectList(_context.Admins, "AId", "AId", train.AId);
            return View(train);
        }

        // GET: Train/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var train = await _context.Trains.FindAsync(id);
            if (train == null)
            {
                return NotFound();
            }
            ViewData["AId"] = new SelectList(_context.Admins, "AId", "AId", train.AId);
            return View(train);
        }

        // POST: Train/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("TId,AId,TName,TSource,TDestination,TDepartureDate,TArrivalTime,TDepartureTime,TFare")] Train train)
        {
            if (id != train.TId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(train);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TrainExists(train.TId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["AId"] = new SelectList(_context.Admins, "AId", "AId", train.AId);
            return View(train);
        }

        // GET: Train/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var train = await _context.Trains
                .Include(t => t.AIdNavigation)
                .FirstOrDefaultAsync(m => m.TId == id);
            if (train == null)
            {
                return NotFound();
            }

            return View(train);
        }

        // POST: Train/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var train = await _context.Trains.FindAsync(id);
            if (train != null)
            {
                _context.Trains.Remove(train);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TrainExists(int id)
        {
            return _context.Trains.Any(e => e.TId == id);
        }
    }
}

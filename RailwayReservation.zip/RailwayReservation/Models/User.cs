﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace RailwayReservation.Models;

public partial class User
{
    public int UId { get; set; }

    public string UName { get; set; } = null!;

    public string UEmail { get; set; } = null!;

    public string UPassword { get; set; } = null!;

    public string? UAddress { get; set; } = null!;

    // Navigation property for reservations
    public virtual ICollection<Reservation> Reservations { get; set; } = new List<Reservation>();
}

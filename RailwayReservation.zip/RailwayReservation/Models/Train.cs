﻿using System;
using System.Collections.Generic;

namespace RailwayReservation.Models;

public partial class Train
{
    public int TId { get; set; }

    public int AId { get; set; }

    public string TName { get; set; } = null!;

    public string TSource { get; set; } = null!;

    public string TDestination { get; set; } = null!;

    public DateOnly TDepartureDate { get; set; }

    public TimeOnly TArrivalTime { get; set; }

    public TimeOnly TDepartureTime { get; set; }

    public decimal TFare { get; set; }

    public virtual Admin AIdNavigation { get; set; } = null!;

    public virtual ICollection<Reservation> Reservations { get; set; } = new List<Reservation>();
}

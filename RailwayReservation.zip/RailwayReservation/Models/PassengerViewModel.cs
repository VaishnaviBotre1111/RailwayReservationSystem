using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RailwayReservation.Models
{
    public class PassengerViewModel
    {

        public string Name { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public int Age { get; set; }
        public string? Gender { get; set; }
        public string? Address { get; set; }
        public long MobileNo { get; set; }
        public long AdharNo { get; set; }
        public DateOnly Dob { get; set; }
        
    }
}
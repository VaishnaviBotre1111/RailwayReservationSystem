using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RailwayReservation.Models
{
    public class AdminDashboardViewModel
{
    public int TotalTrains { get; set; }
    public int TotalUsers { get; set; }
    public int TotalPassengers { get; set; }
    public int TotalReservations { get; set; }
    public required List<Reservation> TodaysReservations { get; set; } // Assuming Reservation is your model
}
}
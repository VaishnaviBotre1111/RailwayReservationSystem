﻿using System;
using System.Collections.Generic;

namespace RailwayReservation.Models;

public partial class Reservation
{
    public int RId { get; set; }

    public int UId { get; set; }

    public int TId { get; set; }

    public long PnrNo { get; set; }

    public decimal RTotalPrice { get; set; }

    public string RBookingStatus { get; set; } = null!;

    public string RPaymentStatus { get; set; } = null!;

    public DateOnly RBookingDate { get; set; }

    public virtual Train TIdNavigation { get; set; } = null!;
    public virtual Passenger PnrNoNavigation { get; set; } = null!;
    public virtual User UIdNavigation { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace RailwayReservation.Models;

public partial class RailwayReservationContext : DbContext
{
    public RailwayReservationContext()
    {
    }

    public RailwayReservationContext(DbContextOptions<RailwayReservationContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Admin> Admins { get; set; }

    public virtual DbSet<Passenger> Passengers { get; set; }

    public virtual DbSet<Reservation> Reservations { get; set; }

    public virtual DbSet<Train> Trains { get; set; }

    public virtual DbSet<User> Users { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!optionsBuilder.IsConfigured)
        {

        }
    }
    // #warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
    //         => optionsBuilder.UseSqlServer("Data Source=LIN-PF2WMFSB; Initial Catalog=RailwayReservation;Integrated Security=True;TrustServerCertificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Admin>(entity =>
        {
            entity.HasKey(e => e.AId);

            entity.ToTable("admin");

            entity.Property(e => e.AId).HasColumnName("a_id");
            entity.Property(e => e.AEmail)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("a_email");
            entity.Property(e => e.AName)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("a_name");
            entity.Property(e => e.APassword)
                .HasMaxLength(10)
                .IsFixedLength()
                .HasColumnName("a_password");
        });

        modelBuilder.Entity<Passenger>(entity =>
        {
            entity.HasKey(e => e.PnrNo);

            entity.ToTable("passengers");

            entity.Property(e => e.PnrNo).HasColumnName("pnr_no");
            entity.Property(e => e.PAddress)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("p_address");
            entity.Property(e => e.PAdharNo).HasColumnName("p_adhar_no");
            entity.Property(e => e.PAge).HasColumnName("p_age");
            entity.Property(e => e.PDob).HasColumnName("p_dob");
            entity.Property(e => e.PEmail)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("p_email");
            entity.Property(e => e.PGender)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("p_gender");
            entity.Property(e => e.PMobileNo).HasColumnName("p_mobile_no");
            entity.Property(e => e.PName)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("p_name");
            entity.Property(e => e.PSeatNo).HasColumnName("p_seat_no");
        });

        //    modelBuilder.Entity<Reservation>(entity =>

        modelBuilder.Entity<Reservation>(entity =>
    {
        entity.HasKey(e => e.RId);

        entity.ToTable("reservations");

        entity.Property(e => e.RId).HasColumnName("r_id");
        entity.Property(e => e.PnrNo).HasColumnName("pnr_no");
        entity.Property(e => e.RBookingDate).HasColumnName("r_booking_date");
        entity.Property(e => e.RBookingStatus)
            .HasMaxLength(20)
            .IsUnicode(false)
            .HasColumnName("r_booking_status");
        entity.Property(e => e.RPaymentStatus)
            .HasMaxLength(20)
            .IsUnicode(false)
            .HasColumnName("r_payment_status");
        entity.Property(e => e.RTotalPrice)
            .HasColumnType("decimal(10, 2)")
            .HasColumnName("r_total_price");
        entity.Property(e => e.TId).HasColumnName("t_id");
        entity.Property(e => e.UId).HasColumnName("u_id");

        entity.HasOne(d => d.TIdNavigation).WithMany(p => p.Reservations)
            .HasForeignKey(d => d.TId)
            .OnDelete(DeleteBehavior.ClientSetNull)
            .HasConstraintName("FK_reservations_users");
    });

        modelBuilder.Entity<Reservation>(entity =>
        {
            entity.HasKey(e => e.RId);

            entity.ToTable("reservations");

            entity.Property(e => e.RId).HasColumnName("r_id");
            entity.Property(e => e.UId).HasColumnName("u_id");
            entity.Property(e => e.TId).HasColumnName("t_id");
            entity.Property(e => e.PnrNo).HasColumnName("pnr_no");
            entity.Property(e => e.RTotalPrice).HasColumnType("decimal(10, 2)").HasColumnName("r_total_price");
            entity.Property(e => e.RBookingStatus).HasMaxLength(20).IsUnicode(false).HasColumnName("r_booking_status");
            entity.Property(e => e.RPaymentStatus).HasMaxLength(20).IsUnicode(false).HasColumnName("r_payment_status");
            entity.Property(e => e.RBookingDate).HasColumnName("r_booking_date");

            // Configure foreign key relationships
            entity.HasOne(d => d.UIdNavigation)
                .WithMany(u => u.Reservations)  // Assuming User has a collection of Reservations
                .HasForeignKey(d => d.UId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_reservations_users");

            entity.HasOne(d => d.TIdNavigation)
                .WithMany(t => t.Reservations)  // Assuming Train has a collection of Reservations
                .HasForeignKey(d => d.TId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_reservations_trains");

            entity.HasOne(d => d.PnrNoNavigation)
                .WithMany(p => p.Reservations)  // Assuming Passenger has a collection of Reservations
                .HasForeignKey(d => d.PnrNo)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_reservations_passengers");
        });


        modelBuilder.Entity<Train>(entity =>
        {
            entity.HasKey(e => e.TId);

            entity.ToTable("trains");

            entity.Property(e => e.TId)
                .ValueGeneratedNever()
                .HasColumnName("t_id");
            entity.Property(e => e.AId).HasColumnName("a_id");
            entity.Property(e => e.TArrivalTime)
                .HasPrecision(0)
                .HasColumnName("t_arrival_time");
            entity.Property(e => e.TDepartureDate).HasColumnName("t_departure_date");
            entity.Property(e => e.TDepartureTime)
                .HasPrecision(0)
                .HasColumnName("t_departure_time");
            entity.Property(e => e.TDestination)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("t_destination");
            entity.Property(e => e.TFare)
                .HasColumnType("decimal(10, 2)")
                .HasColumnName("t_fare");
            entity.Property(e => e.TName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("t_name");
            entity.Property(e => e.TSource)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("t_source");

            entity.HasOne(d => d.AIdNavigation).WithMany(p => p.Trains)
                .HasForeignKey(d => d.AId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_trains_admin");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.UId);

            entity.ToTable("users");

            entity.Property(e => e.UId).HasColumnName("u_id");
            entity.Property(e => e.UAddress)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("u_address");
            entity.Property(e => e.UEmail)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("u_email");
            entity.Property(e => e.UName)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("u_name");
            entity.Property(e => e.UPassword)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("u_password");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}

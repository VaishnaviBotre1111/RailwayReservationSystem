using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RailwayReservation.Models
{
    public class ReservationDetailsViewModel
    {
        
        public int ReservationId { get; set; }
        public int TrainId { get; set; }
        public required string TrainName { get; set; }
        public int UserId { get; set; }
        public long PnrNo { get; set; }
        public required string UserName { get; set; }
        public required string Source { get; set; }
        public required string Destination { get; set; }
        public DateOnly DepartureDate { get; set; }
        public TimeOnly ArrivalTime { get; set; }
        public TimeOnly DepartureTime { get; set; }
        public decimal TotalPrice { get; set; }
        public DateOnly BookingDate { get; set; }
        public required string PaymentStatus { get; set; }
        public required string BookingStatus { get; set; }
        public required string PassengerName { get; set; }
        public int PassengerAge { get; set; }
        public string? PassengerAddress { get; set; }
        public long PassengerMobileNo { get; set; }
        public long PassengerAdharNo { get; set;}
        public int SeatNo { get; set; }

    }
}
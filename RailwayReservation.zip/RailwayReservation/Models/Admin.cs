﻿using System;
using System.Collections.Generic;

namespace RailwayReservation.Models;

public partial class Admin
{
    public int AId { get; set; }

    public string AName { get; set; } = null!;

    public string AEmail { get; set; } = null!;

    public string APassword { get; set; } = null!;

    public virtual ICollection<Train> Trains { get; set; } = new List<Train>();
}

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RailwayReservation.Models
{
    public class TrainDetailsViewModel
    {

        public required Train Train { get; set; }
        public required string BookingRules { get; set; }
        public required string CancellationRules { get; set; }

    }
}
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RailwayReservation.Models
{
    public class TrainSearchViewModel
    {
        
        public string? TName { get;set;}
        public string? TSource { get; set; }
        public string? TDestination { get; set; }

        public DateOnly? TDepartureDate {get; set; }
        public List<Train> Trains {get; set;} = new List<Train>();
    }
}
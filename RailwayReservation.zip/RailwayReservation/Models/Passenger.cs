﻿using System;
using System.Collections.Generic;

namespace RailwayReservation.Models;

public partial class Passenger
{
    public long PnrNo { get; set; }

    public string PName { get; set; } = null!;

    public string PEmail { get; set; } = null!;

    public int PAge { get; set; }

    public string? PGender { get; set; }

    public string? PAddress { get; set; }

    public long PMobileNo { get; set; }

    public long PAdharNo { get; set; }

    public DateOnly PDob { get; set; }

    public int PSeatNo { get; set; }

    // Navigation property for reservations
    public virtual ICollection<Reservation> Reservations { get; set; } = new List<Reservation>();
}
